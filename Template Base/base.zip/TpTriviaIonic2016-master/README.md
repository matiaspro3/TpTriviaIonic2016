# TpTriviaIonic2016
Trabajo práctico de PPS2016
-----------------------------------------------------------------------------
trivia : crear una trivia de minimo 3 preguntas con única respuesta y varias opciones, al menos tres . La aplicación debe tener :  icono, imagen de inicio , ingreso de usuario(emular login solo con nombre),Pagina del autor(nombre, apellido, foto de perfil, mail, gitHub  )
